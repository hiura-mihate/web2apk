/**
 * Generate inline keyboards for bot
 *
 * Since Telegram Bot API 9.4, InlineKeyboardButton supports a real `style`
 * field: 'primary' (blue), 'success' (green), or 'danger' (red). Every
 * button below sets one so the whole keyboard renders in color on clients
 * that support it; on older clients the field is simply ignored and the
 * button falls back to the normal default look - fully backward compatible.
 */

// Main menu keyboard
function getMainKeyboard() {
    return {
        inline_keyboard: [
            [
                { text: '📱 BUAT APLIKASI (URL)', callback_data: 'create_apk', style: 'success' },
                { text: '📦 BUILD PROJECT (ZIP)', callback_data: 'build_zip', style: 'primary' }
            ],
            [
                { text: '📋 Cek Antrian', callback_data: 'check_queue', style: 'primary' },
                { text: '📜 Menu Perintah', callback_data: 'show_commands', style: 'primary' },
                { text: '❓ Bantuan', callback_data: 'help', style: 'primary' }
            ],
            [
                { text: '👤 Owner', url: 'https://t.me/Hiurafemx', style: 'primary' },
                { text: '🙏 TQTO', callback_data: 'thanks_to', style: 'primary' },
                { text: '📢 Channel', url: 'https://t.me/Hiura_femx', style: 'primary' }
            ]
        ]
    };
}

// Color selection keyboard (theme color of the generated app)
function getColorKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🔵 Biru', callback_data: 'color_blue', style: 'primary' }, { text: '🔴 Merah', callback_data: 'color_red', style: 'danger' }, { text: '🟢 Hijau', callback_data: 'color_green', style: 'success' }],
            [{ text: '🟣 Ungu', callback_data: 'color_purple', style: 'primary' }, { text: '🟠 Oranye', callback_data: 'color_orange', style: 'primary' }, { text: '🔵 Teal', callback_data: 'color_teal', style: 'primary' }],
            [{ text: '💗 Pink', callback_data: 'color_pink', style: 'primary' }, { text: '🔵 Indigo', callback_data: 'color_indigo', style: 'primary' }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

// Build type keyboard - choose the output format of the generated app
function getBuildTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🐛 APK Testing (Cepat, Debug)', callback_data: 'bt_debug', style: 'primary' }],
            [{ text: '🚀 APK Release (Sudah Ditandatangani)', callback_data: 'bt_release', style: 'success' }],
            [{ text: '🏪 App Bundle - Play Store (AAB)', callback_data: 'bt_bundle', style: 'success' }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

// Confirmation keyboard
function getConfirmKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '✅ Buat APK', callback_data: 'confirm_build', style: 'success' }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

// Cancel keyboard
function getCancelKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

// Icon upload keyboard
function getIconKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '⏭️ Lewati (Gunakan Default)', callback_data: 'skip_icon', style: 'primary' }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

// ZIP project type keyboard
function getZipTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🤖 Android Studio / Gradle', callback_data: 'zip_android', style: 'primary' }, { text: '💙 Flutter Project', callback_data: 'zip_flutter', style: 'primary' }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

// ZIP build type keyboard (debug/release)
function getZipBuildTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🐛 Debug APK (Fast)', callback_data: 'zipbuild_debug', style: 'primary' }, { text: '🚀 Release APK', callback_data: 'zipbuild_release', style: 'success' }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: 'danger' }]
        ]
    };
}

module.exports = {
    getMainKeyboard,
    getColorKeyboard,
    getBuildTypeKeyboard,
    getConfirmKeyboard,
    getCancelKeyboard,
    getIconKeyboard,
    getZipTypeKeyboard,
    getZipBuildTypeKeyboard
};
