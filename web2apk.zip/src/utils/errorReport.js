const path = require('path');

/**
 * Extract structured "file : line : message" entries from a raw Gradle /
 * Flutter / Java / Kotlin build log. Best-effort regex matching across the
 * common formats these toolchains print - it won't catch 100% of cases, but
 * covers the vast majority of real compiler/resource errors.
 *
 * @param {string} rawLog - Full combined stdout+stderr from the build process
 * @param {string} [projectDir] - Absolute path to the generated project, used
 *   to shorten absolute paths down to something readable (relative to project root)
 * @returns {Array<{file: string, line: number, column: number|null, message: string}>}
 */
function extractErrorLocations(rawLog, projectDir) {
    if (!rawLog || typeof rawLog !== 'string') return [];

    const results = [];
    const seen = new Set();

    const addResult = (rawFilePath, line, column, message) => {
        if (!rawFilePath || !line) return;

        let displayPath = rawFilePath.trim();
        if (projectDir && displayPath.startsWith(projectDir)) {
            displayPath = path.relative(projectDir, displayPath) || displayPath;
        }
        displayPath = displayPath.replace(/\\/g, '/');

        const cleanMessage = (message || '').trim().substring(0, 220) || '(lihat log lengkap di bawah)';
        const key = `${displayPath}:${line}:${cleanMessage.substring(0, 60)}`;
        if (seen.has(key)) return;
        seen.add(key);

        results.push({
            file: displayPath,
            line: parseInt(line, 10),
            column: column ? parseInt(column, 10) : null,
            message: cleanMessage
        });
    };

    // 1. Java / Groovy / AAPT / XML style: /abs/path/File.ext:LINE: error: message
    const genericPattern = /([^\s:()'"]+\.(?:java|kt|kts|gradle|xml|dart)):(\d+):(?:(\d+):)?\s*(?:error|warning)?:?\s*(.*)/gi;
    let m;
    while ((m = genericPattern.exec(rawLog)) !== null && results.length < 25) {
        addResult(m[1], m[2], m[3], m[4]);
    }

    // 2. Kotlin (older) style: e: file:///abs/path/File.kt: (12, 5): message
    const kotlinOldPattern = /^e:\s*file:\/\/(\/[^\s:]+\.kt):\s*\((\d+),\s*(\d+)\):\s*(.*)$/gim;
    while ((m = kotlinOldPattern.exec(rawLog)) !== null && results.length < 25) {
        addResult(m[1], m[2], m[3], m[4]);
    }

    // 3. Dart analyzer style: lib/main.dart:25:10: Error: message
    const dartPattern = /^([\w./-]+\.dart):(\d+):(\d+):\s*(?:Error|Warning):\s*(.*)$/gim;
    while ((m = dartPattern.exec(rawLog)) !== null && results.length < 25) {
        addResult(m[1], m[2], m[3], m[4]);
    }

    return results.slice(0, 25);
}

/**
 * Build a full, human-readable (Indonesian) error report combining detected
 * file/line locations, the short error summary, and the raw build log.
 *
 * @param {Object} opts
 * @param {string} opts.appName - Name of the app/project being built
 * @param {string} opts.context - e.g. "URL Build (release)" or "ZIP Build - Flutter (debug)"
 * @param {string} [opts.shortError] - Short, already-parsed error message
 * @param {string} [opts.rawLog] - Full raw stdout+stderr from the build tool, if available
 * @param {string} [opts.projectDir] - Absolute path to the generated project (for relative paths)
 * @returns {{ text: string, locations: Array, hasRawLog: boolean }}
 */
function buildErrorReportText(opts) {
    const { appName, context, shortError, rawLog, projectDir } = opts || {};
    const locations = extractErrorLocations(rawLog, projectDir);

    const lines = [];
    lines.push('===================================================='.trim());
    lines.push(' LAPORAN ERROR BUILD - Web2APK Bot');
    lines.push('===================================================='.trim());
    lines.push('');
    lines.push(`Aplikasi   : ${appName || '-'}`);
    lines.push(`Konteks    : ${context || '-'}`);
    lines.push(`Waktu      : ${new Date().toLocaleString('id-ID')}`);
    lines.push('');
    lines.push('----------------------------------------------------');
    lines.push(locations.length > 0
        ? `LOKASI ERROR TERDETEKSI (${locations.length})`
        : 'LOKASI ERROR');
    lines.push('----------------------------------------------------');

    if (locations.length > 0) {
        locations.forEach((loc, i) => {
            lines.push(`[${i + 1}] Folder/File : ${loc.file}`);
            lines.push(`    Baris       : ${loc.line}${loc.column ? ':' + loc.column : ''}`);
            lines.push(`    Error       : ${loc.message}`);
            lines.push('');
        });
    } else {
        lines.push('Tidak ditemukan lokasi file:baris yang spesifik secara');
        lines.push('otomatis. Lihat ringkasan & log lengkap di bawah untuk detail.');
        lines.push('');
    }

    if (shortError) {
        lines.push('----------------------------------------------------');
        lines.push('RINGKASAN ERROR');
        lines.push('----------------------------------------------------');
        lines.push(String(shortError).trim());
        lines.push('');
    }

    if (rawLog) {
        lines.push('----------------------------------------------------');
        lines.push('LOG LENGKAP (RAW OUTPUT)');
        lines.push('----------------------------------------------------');
        const maxChars = 60000; // keep the .txt a reasonable size
        const trimmedLog = rawLog.length > maxChars
            ? `...(dipotong, menampilkan ${maxChars} karakter terakhir dari total ${rawLog.length})...\n\n` + rawLog.slice(-maxChars)
            : rawLog;
        lines.push(trimmedLog.trim());
        lines.push('');
    }

    lines.push('====================================================');
    lines.push('Dibuat otomatis oleh Web2APK Bot');

    return {
        text: lines.join('\n'),
        locations,
        hasRawLog: !!rawLog
    };
}

module.exports = { extractErrorLocations, buildErrorReportText };
